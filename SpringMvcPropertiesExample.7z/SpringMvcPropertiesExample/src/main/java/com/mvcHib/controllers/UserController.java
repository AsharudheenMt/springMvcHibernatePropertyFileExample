package com.mvcHib.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mvcHib.dao.UserDao;
import com.mvcHib.model.Login;
import com.mvcHib.model.User;

@Controller
public class UserController {
	@Autowired
	private UserDao userDao;

	@GetMapping("/")
	public String welcome() {
		return "index";
	}

	@PostMapping("add-user")
	public String addUser(User user, Login login) {
		userDao.saveUser(user, login);
		return "success";

	}

	@GetMapping("/log-form")
	public String loginform() {
		return "login-form";

	}

	@PostMapping(value = "log-action", consumes = "application/x-www-form-urlencoded")
	public ModelAndView logAction(Login login) {
		ModelAndView mv = new ModelAndView();
		User user = userDao.loginUser(login);
		if (user != null) {
			mv.setViewName("profile");
			mv.addObject("user", user);
			return mv;
		} else {
			mv.setViewName("error");
			return mv;

		}
	}

}
