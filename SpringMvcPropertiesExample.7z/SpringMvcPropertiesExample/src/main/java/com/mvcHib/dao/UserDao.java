package com.mvcHib.dao;

import com.mvcHib.model.Login;
import com.mvcHib.model.User;

public interface UserDao {

	public void saveUser(User user, Login login);

	public User loginUser(Login login);
}
