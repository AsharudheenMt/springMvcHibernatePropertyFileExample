package com.mvcHib.dao;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mvcHib.model.Login;
import com.mvcHib.model.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void saveUser(User user, Login login) {
		sessionFactory.getCurrentSession().save(login);
		user.setLogin(login);
		sessionFactory.getCurrentSession().save(user);
	}

	public User loginUser(Login login) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(" from Login m where m.email=:e AND m.password=:p", Login.class);
		query.setParameter("e", login.getEmail());
		query.setParameter("p", login.getPassword());
		Login l = (Login) query.getSingleResult();

		NativeQuery<User> query1 = session.createNativeQuery("select * from user_details where loginid=:lid",
				User.class);
		return query1.setParameter("lid", l.getLogid()).list().get(0);
	}

}
